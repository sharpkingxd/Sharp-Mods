# Default Configuration

Below you can find the default configuration files for ServerCore.\
These are recommended for most users, as it has little to no impact on behavior while still improving performance.

### optimizations.yml

```yml
# Allows you to toggle specific optimizations that don't have full vanilla parity.
# These settings will only take effect after server restarts.

# Prevents many different lagspikes caused by loading chunks synchronously.
# This for example causes maps to only update loaded chunks, which depending on the viewdistance can be a smaller radius than vanilla.
reduce-sync-loads: true
# Can significantly reduce the time spent on chunk iteration by only updating the ticking chunks list each second, rather than each tick.
# This is especially useful for servers with a high playercount and / or viewdistance.
cache-ticking-chunks: true
# Optimizes command block executions by caching parsed commands.
# Command parsing is a relatively expensive operation. By caching it we avoid parsing the same command every time it is executed.
optimize-command-blocks: false
# Can significantly reduce time spent on mobspawning, but isn't as accurate as vanilla on biome borders.
# This may cause mobs from another biome to spawn a few blocks across a biome border (this does not affect structure spawning!).
fast-biome-lookups: false
# Fluid random ticks, like lava spreading fire, are run twice each game tick.
# Enabling this will cancel the 'duplicate' second fluid tick, but this may cause slight behavior changes.
cancel-duplicate-fluid-ticks: false
```

### config.yml

```yml
# The main configuration file for ServerCore.
# Most of these settings can be reloaded without restarting using /servercore reload.

# Most miscellaneous feature toggles.
features:
  # Reverts enderpearl behavior to pre-1.21.2. The following will change when this setting is enabled:
  # ► Enderpearls will no longer load chunks around them.
  # ► Enderpearls will load / unload with chunks again instead of with their owner joining / leaving the game.
  # Note: Toggling this setting may cause some old enderpearls from before the toggle to be lost.
  prevent-enderpearl-chunkloading: false
  # Whether the chunk-tick-distance dynamic setting should affect random ticks.
  # Enabling this will stop chunks from performing random ticks when they are outside of this distance from any player.
  # That includes chunks loaded by enderpearls or portals, breaking vanilla behavior.
  chunk-tick-distance-affects-random-ticks: false
  # Prevents lagspikes caused by players moving into unloaded chunks.
  prevent-moving-into-unloaded-chunks: false
  # The amount of seconds between auto-saves when /save-on is active.
  autosave-interval-seconds: 300
  # The fraction that decides the chance of experience orbs being able to merge with each other. (1 = 100%, 40 = 2.5%)
  # Note that just like in vanilla, experience orbs will still need to be of the same size to actually merge.
  xp-merge-fraction: 40
  # The radius in blocks that experience orbs will merge at.
  xp-merge-radius: 0.5
  # The radius in blocks that items will merge at.
  item-merge-radius: 0.5
  lobotomize-villagers:
    # Makes villagers tick less often if they are stuck in a 1x1 space.
    enabled: false
    # Decides the interval in between villager ticks when lobotomized.
    tick-interval: 20

# Automatically modifies dynamic settings based on the server performance.
dynamic:
  # Enables dynamic performance checks.
  enabled: false
  # The average MSPT to target.
  target-mspt: 35
  # The default values for dynamic settings.
  # If left unspecified, the maximum value will be used.
  # Note: adding view / simulation distance here will override their value in server.properties.
  default-values:
    MOBCAP_PERCENTAGE: 100
    CHUNK_TICK_DISTANCE: 10

  # The settings that will be decreased when the server is overloaded, in the specified order.
  # You can remove settings from the list that you don't want to be dynamically adjusted.
  # ► max = The maximum value the server will increase the setting to.
  # ► min = The minimum value the server will decrease the setting to.
  # ► increment = The amount the setting will be increased or decreased by.
  # ► interval = The amount of seconds between each check to increase or decrease.
  dynamic-settings:
    - setting: 'CHUNK_TICK_DISTANCE'
      max: 10
      min: 6
      increment: 1
      interval: 15

    - setting: 'MOBCAP_PERCENTAGE'
      max: 100
      min: 50
      increment: 10
      interval: 15

    - setting: 'SIMULATION_DISTANCE'
      max: 10
      min: 6
      increment: 1
      interval: 15

    - setting: 'CHUNK_TICK_DISTANCE'
      max: 6
      min: 2
      increment: 1
      interval: 15

    - setting: 'MOBCAP_PERCENTAGE'
      max: 50
      min: 30
      increment: 10
      interval: 15

    - setting: 'SIMULATION_DISTANCE'
      max: 6
      min: 2
      increment: 1
      interval: 15

    - setting: 'VIEW_DISTANCE'
      max: 10
      min: 5
      increment: 1
      interval: 150

# A special mobcap that only affects the breeding of animals and villagers.
breeding-cap:
  # Enables breeding caps.
  enabled: false
  # The breeding cap for villagers.
  # ► limit = The limit of mobs of the same type within range. Setting this to negative will disable the breeding cap.
  # ► range = The range it will check for entities of the same type.
  # ► unlimited-height = Whether to ignore the vertical distance when checking for entities of the same type.
  villagers:
    limit: 32
    range: 64
    unlimited-height: false

  # The breeding cap for animals.
  # Note that this cap only checks for animals of the same type.
  # If the limit is 32 you can still breed 32 cows and 32 pigs next to each other.
  animals:
    limit: 32
    range: 64
    unlimited-height: false

# Gives more control over mob spawning.
mob-spawning:
  # Mobcap settings for zombie reinforcements.
  # ► enforce-mobcap = Whether to enforce mobcaps for this type of mobspawning.
  # ► additional-capacity = Additional capacity for this specific mobcap. Decides how much it can spawn over the regular mobcap.
  # It is recommended to allow them to spawn a bit over the regular mobcap as they would otherwise never get a chance to spawn.
  zombie-reinforcements:
    enforce-mobcap: false
    additional-capacity: 32

  # Mobcap settings for zombified piglin spawning from nether portal random ticks.
  nether-portal-randomticks:
    enforce-mobcap: false
    additional-capacity: 32

  # Mobcap settings for mobs spawned from monster spawners.
  monster-spawners:
    enforce-mobcap: false
    additional-capacity: 32

  # Mobcap settings for silverfish spawned from the infested potion effect.
  infested:
    enforce-mobcap: false
    additional-capacity: 32

  # A list of mob categories with their respective mobcap and spawn interval.
  # ► category = The vanilla spawn category.
  # ► mobcap = The maximum amount of entities in the same category that can spawn near a player.
  # ► spawn-interval = The interval between spawn attempts in ticks. Higher values mean less frequent spawn attempts.
  categories:
    - category: 'MONSTER'
      mobcap: 70
      spawn-interval: 1

    - category: 'CREATURE'
      mobcap: 10
      spawn-interval: 400

    - category: 'AMBIENT'
      mobcap: 15
      spawn-interval: 1

    - category: 'AXOLOTLS'
      mobcap: 5
      spawn-interval: 1

    - category: 'UNDERGROUND_WATER_CREATURE'
      mobcap: 5
      spawn-interval: 1

    - category: 'WATER_CREATURE'
      mobcap: 5
      spawn-interval: 1

    - category: 'WATER_AMBIENT'
      mobcap: 20
      spawn-interval: 1

# Settings for commands and their formatting.
commands:
  # Enables the /servercore status command.
  status-enabled: true
  # Enables the /mobcaps command.
  mobcaps-enabled: true
  colors:
    # The colors used in command feedback. You can use hex codes or minecraft legacy color names.
    # The primary color is the most used color in command feedback.
    primary: 'dark_aqua'
    # The secondary color is used for highlighting important information, like values.
    secondary: 'green'
    # The tertiary color is mostly used for text in titles.
    tertiary: 'aqua'

# Activation range can drastically reduce the amount of lag caused by ticking entities.
# It does this by cleverly skipping certain entity ticks based on the distance to players and other factors, like immunity checks.
# Immunity checks determine whether an entity should be ticked even when it's outside the activation range, like for example when it is falling or takes damage.
# Note: while this is a very powerful feature, it can still slow down mobfarms and break very specific technical contraptions.
activation-range:
  # Enables activation range.
  enabled: false
  # Briefly ticks entities newly added to the world for 10 seconds (includes both spawning and loading).
  # This gives them a chance to properly immunize when they are spawned if they should be. Can be helpful for mobfarms.
  tick-new-entities: true
  # Enables vertical range checks. By default, activation ranges only work horizontally.
  # This can greatly improve performance on taller worlds, but might break a few very specific ai-based mobfarms.
  use-vertical-range: false
  # Skips 1/4th of entity ticks whilst not immune.
  # This affects entities that are within the activation range, but not immune (for example by falling or being in water).
  skip-non-immune: false
  # Allows villagers to tick regardless of the activation range when panicking.
  villager-tick-panic: true
  # The time in seconds that a villager needs to be inactive for before obtaining work immunity (if it has work tasks).
  villager-work-immunity-after: 20
  # The amount of ticks an inactive villager will wake up for when it has work immunity.
  villager-work-immunity-for: 20
  # A list of entity types that should be excluded from activation range checks.
  excluded-entity-types:
    - 'minecraft:ghast'
    - 'minecraft:hopper_minecart'
    - 'minecraft:warden'
  # The activation type that will get assigned to any entity that doesn't have a custom activation type.
  # ► activation-range = The range an entity is required to be in from a player to be activated.
  # ► tick-interval = The interval between 'active' ticks whilst the entity is inactive. Negative values will disable these active ticks.
  # ► wakeup-interval = The interval between inactive entity wakeups in seconds.
  # ► extra-height-up = Allows entities to be ticked when far above the player when vertical range is in use.
  # ► extra-height-down = Allows entities to be ticked when far below the player when vertical range is in use.
  default-activation-type:
    activation-range: 16
    tick-interval: 20
    wakeup-interval: -1
    extra-height-up: false
    extra-height-down: false

  # A list of custom activation types.
  # ► name = The name of the activation type.
  # ► entity-matcher = A list of conditions to filter entities. Only one of these conditions needs to be met for an entity to match.
  # ► If an entity matches multiple activation types, the one highest in the list will be used. The conditions accept the following formats:
  #   - Entity type matching    |   Uses the entity type's identifier.  |  'minecraft:zombie' matches zombies, but for example not husks or drowned.
  #   - Typeof class matching   |   Uses the 'typeof:' prefix.          |  'typeof:monster' matches all monsters.
  # ► Available typeof classes: mob, monster, raider, neutral, ambient, animal, water_animal, flying_animal, villager, projectile.
  custom-activation-types:
    - name: 'raider'
      activation-range: 48
      tick-interval: 20
      wakeup-interval: 20
      extra-height-up: true
      extra-height-down: false
      entity-matcher:
        - 'typeof:raider'

    - name: 'water'
      activation-range: 16
      tick-interval: 20
      wakeup-interval: 60
      extra-height-up: false
      extra-height-down: false
      entity-matcher:
        - 'typeof:water_animal'

    - name: 'villager'
      activation-range: 16
      tick-interval: 20
      wakeup-interval: 30
      extra-height-up: false
      extra-height-down: false
      entity-matcher:
        - 'typeof:villager'

    - name: 'zombie'
      activation-range: 16
      tick-interval: 20
      wakeup-interval: 20
      extra-height-up: true
      extra-height-down: false
      entity-matcher:
        - 'minecraft:zombie'
        - 'minecraft:husk'

    - name: 'monster-below'
      activation-range: 32
      tick-interval: 20
      wakeup-interval: 20
      extra-height-up: true
      extra-height-down: true
      entity-matcher:
        - 'minecraft:creeper'
        - 'minecraft:slime'
        - 'minecraft:magma_cube'
        - 'minecraft:hoglin'

    - name: 'flying-monster'
      activation-range: 48
      tick-interval: 20
      wakeup-interval: 20
      extra-height-up: true
      extra-height-down: false
      entity-matcher:
        - 'minecraft:ghast'
        - 'minecraft:phantom'

    - name: 'monster'
      activation-range: 32
      tick-interval: 20
      wakeup-interval: 20
      extra-height-up: true
      extra-height-down: false
      entity-matcher:
        - 'typeof:monster'

    - name: 'animal'
      activation-range: 16
      tick-interval: 20
      wakeup-interval: 60
      extra-height-up: false
      extra-height-down: false
      entity-matcher:
        - 'typeof:animal'
        - 'typeof:ambient'

    - name: 'creature'
      activation-range: 24
      tick-interval: 20
      wakeup-interval: 30
      extra-height-up: false
      extra-height-down: false
      entity-matcher:
        - 'typeof:mob'
```